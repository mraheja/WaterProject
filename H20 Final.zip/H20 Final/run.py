from flask import *
import requests
import os
import convert
import survive

app = Flask(__name__,static_folder='C:\\Users\\rahej\\Desktop\\H20 Final\\static')

coords = []
icons = []
deetz = []
iconURLs = ["https://github.com/mraheja/WaterProject/blob/master/full-tiny.png?raw=true","https://github.com/mraheja/WaterProject/blob/master/mostlyfull-tiny.png?raw=true","https://github.com/mraheja/WaterProject/blob/master/empty-tiny.png?raw=true","https://github.com/mraheja/WaterProject/blob/master/critical-tiny.png?raw=true"]


@app.route('/')
def welcome():
	return open('index.html').read()

@app.route('/SignUp')
def SignUp():
	return open('form.html').read()

def jsMarkers():
	s = "["
	print("HERE",coords)
	cur_s = ""
	for i,e in enumerate(coords):
		cur_s += "new google.maps.Marker("
		cur_s += "{position:"
		cur_s += e
		cur_s += ", map: map,  icon: '"
		cur_s += iconURLs[icons[i]]
		cur_s += "'}),"
	if(len(coords) > 0):
		s += cur_s[0:len(cur_s)-1]
	s += "]"
	return s

def jsListeners():
	s = ""
	for i in range(len(coords)):
		s += "markers[" + str(i) + "].addListener('click',a" + str(i) + ");"
	return s

def jsListenerFunctions():
	s = ""
	for i in range(len(coords)):
		s += "function a" + str(i) + "(){document.getElementById('hello').innerHTML = '" + str(deetz[i]) + "'}"
	return s

@app.route('/map')
def map():
	f = open('map.js','w')
	s = "function initMap() {  var map = new google.maps.Map(document.getElementById('map'), {zoom: 2, center: {'lat': 0, 'lng': 0}});"
	s += "var markers = " + jsMarkers() + ";"
	s += jsListeners()
	s += "}"
	s += jsListenerFunctions()
	f.write(s)
	f.close()
	return open('map.html').read().replace("REPLACETHIS",open('map.js').read())

@app.route('/water-python', methods = ['POST'])
def waterPython():
	name = request.form['name']
	phone = request.form['phone']
	email = request.form['email']
	address = request.form['address']
	people = int(request.form['people'])
	unit = request.form['unit']
	waterNumber = int(request.form['waterNumber'])

	coor = convert.convert(address)
	coords.append(coor)

	

	days = 0
	if("Gallon" in unit):
		days = survive.survivalTime(0,waterNumber,0,people)
	if("Bottles" in unit):
		days = survive.survivalTime(waterNumber,0,0,people)
	if("Ounces" in unit):
		days = survive.survivalTime(0,0,waterNumber,people)

	details = phone + " <br/> " + email + " <br/>"
	deetz.append(details)
	print(name,phone,email,unit,waterNumber)

	iconi = 0
	if(days < 1):
		iconi = 3
	elif(days < 2):
		iconi = 2
	elif(days < 3):
		iconi = 1

	icons.append(iconi)

	return ('', 204)
if __name__ == '__main__':
    app.run(host='0.0.0.0',port = '80',debug = True)